/* Manhwa Sheet — GM configuration apps (Configure Settings → Manhwa Sheet) */
import { SYS, esc, uid, getConfig, setConfig, DEFAULT_CONFIG, ITEM_FIELDS, costOfStep, costBetween, flattenTree } from "./config.js";
const { ApplicationV2 } = foundry.applications.api; const DialogV2 = foundry.applications.api.DialogV2;
const slug = s => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "") || uid();
const fmt = n => new Intl.NumberFormat("en-US").format(Number(n) || 0);
const inp = (path, v, type = "text", extra = "") => `<input type="${type}" data-path="${path}" value="${esc(v ?? "")}" ${extra}>`;
const chk = (path, v, label) => `<label class="ms-chk"><input type="checkbox" data-path="${path}"${v ? " checked" : ""}><span>${label}</span></label>`;
const color = (path, v) => `<input type="color" data-path="${path}" value="${esc(v || "#38a8ff")}">`;
const rowBtns = (list, i, n) => `<span class="ms-rb"><a data-act="up" data-list="${list}" data-i="${i}" ${i === 0 ? "class='off'" : ""}><i class="fa-solid fa-chevron-up"></i></a><a data-act="down" data-list="${list}" data-i="${i}" ${i === n - 1 ? "class='off'" : ""}><i class="fa-solid fa-chevron-down"></i></a><a data-act="del" data-list="${list}" data-i="${i}" class="danger"><i class="fa-solid fa-xmark"></i></a></span>`;

class BaseConfigApp extends ApplicationV2 {
  static DEFAULT_OPTIONS = { classes: ["ms-config"], window: { resizable: true }, position: { width: 1000, height: 760 } };
  constructor(...a) { super(...a); this.cfg = getConfig(); this.tab = this.constructor.TABS[0][0]; this.dirty = false; }
  async _renderHTML() {
    const tabs = this.constructor.TABS.map(t => `<a data-tab="${t[0]}" class="${this.tab === t[0] ? "on" : ""}"><i class="fa-solid ${t[2]}"></i>${t[1]}</a>`).join("");
    return `<div class="ms-cfg"><nav class="ms-tabs">${tabs}</nav><section class="ms-cfg-body">${this.body()}</section>
      <footer class="ms-cfg-foot"><span class="${this.dirty ? "dirty" : ""}">${this.dirty ? "Unsaved changes" : "Saved"}</span><span class="grow"></span><button data-act="reset"><i class="fa-solid fa-rotate-left"></i> Reset this page to defaults</button><button data-act="export"><i class="fa-solid fa-download"></i> Export JSON</button><button data-act="import"><i class="fa-solid fa-upload"></i> Import JSON</button><button data-act="save" class="primary"><i class="fa-solid fa-check"></i> Save</button></footer></div>`;
  }
  _replaceHTML(r, c) { c.innerHTML = r; this.activate(c.firstElementChild); }
  activate(root) {
    root.querySelectorAll("nav.ms-tabs a").forEach(a => a.addEventListener("click", () => { this.tab = a.dataset.tab; this.render(); }));
    root.addEventListener("change", async ev => { const el = ev.target; if (el.dataset.act) { await this.extraAct(el.dataset.act, el); if (el.type === "checkbox") this.render(); return; } const path = el.dataset.path; if (!path) return; let v = el.type === "checkbox" ? el.checked : el.type === "number" ? (el.value === "" ? 0 : Number(el.value)) : el.value; if (el.dataset.list) v = v.split(",").map(x => x.trim()).filter(Boolean); foundry.utils.setProperty(this.cfg, path, v); this.dirty = true; this.onChanged(path, el); });
    root.addEventListener("click", async ev => { const a = ev.target.closest("[data-act]"); if (!a || a.matches("input,select,textarea")) return; ev.preventDefault(); await this.act(a.dataset.act, a); });
  }
  onChanged() { this.render(); }
  listAt(path) { return foundry.utils.getProperty(this.cfg, path); }
  async act(act, a) {
    const list = a.dataset.list ? this.listAt(a.dataset.list) : null, i = Number(a.dataset.i);
    if (act === "up" && list && i > 0) { [list[i - 1], list[i]] = [list[i], list[i - 1]]; this.dirty = true; }
    else if (act === "down" && list && i < list.length - 1) { [list[i + 1], list[i]] = [list[i], list[i + 1]]; this.dirty = true; }
    else if (act === "del" && list) { list.splice(i, 1); this.dirty = true; }
    else if (act === "save") { await setConfig(this.cfg); this.dirty = false; ui.notifications.info("Manhwa Sheet: configuration saved. Open sheets refresh."); for (const app of foundry.applications.instances.values()) if (app.actor || app.item) app.render(); }
    else if (act === "reset") { const page = this.constructor.RESET[this.tab] || []; for (const k of page) foundry.utils.setProperty(this.cfg, k, foundry.utils.deepClone(foundry.utils.getProperty(DEFAULT_CONFIG, k))); this.dirty = true; }
    else if (act === "export") { const a2 = document.createElement("a"); a2.href = URL.createObjectURL(new Blob([JSON.stringify(this.cfg, null, 2)], { type: "application/json" })); a2.download = `manhwa-sheet-config-${new Date().toISOString().slice(0, 10)}.json`; a2.click(); return; }
    else if (act === "import") { const inp2 = document.createElement("input"); inp2.type = "file"; inp2.accept = ".json"; inp2.onchange = async () => { try { const j = JSON.parse(await inp2.files[0].text()); this.cfg = foundry.utils.mergeObject(foundry.utils.deepClone(DEFAULT_CONFIG), j, { inplace: false }); this.dirty = true; this.render(); } catch (e) { ui.notifications.error("Invalid JSON."); } }; inp2.click(); return; }
    else await this.extraAct(act, a);
    this.render();
  }
  async extraAct() {}
}

/* ═══════════ Sheet configuration ═══════════ */
export class SheetConfigApp extends BaseConfigApp {
  static DEFAULT_OPTIONS = { id: "ms-config", window: { title: "Manhwa Sheet — Sheet configuration", icon: "fa-solid fa-sliders" } };
  static TABS = [["stats", "Stats", "fa-chart-simple"], ["resources", "Currencies", "fa-coins"], ["ranks", "Ranks & colors", "fa-ranking-star"], ["states", "Awakening & origins", "fa-sun"], ["lists", "Lists", "fa-list"], ["items", "Item categories", "fa-sitemap"], ["identity", "Identity sections", "fa-id-card"]];
  static RESET = { stats: ["stats", "statColorMode"], resources: ["resources"], ranks: ["ranks", "rankColor"], states: ["awakening", "origins"], lists: ["rarities", "elements", "costs", "ranges", "executions"], items: ["items", "equipment"], identity: ["identity"] };
  body() {
    const c = this.cfg;
    const simpleList = (key, title, hint, cols) => `<div class="ms-cfg-sec"><h3>${title}</h3><p class="hint">${hint}</p><table class="ms-cfg-table"><thead><tr>${cols.map(x => `<th>${x}</th>`).join("")}<th></th></tr></thead><tbody>${(c[key] || []).map((r, i) => `<tr><td>${inp(`${key}.${i}.name`, r.name)}</td>${cols.includes("Color") ? `<td>${color(`${key}.${i}.color`, r.color)}</td>` : ""}<td><code>${esc(r.key)}</code></td><td>${rowBtns(key, i, c[key].length)}</td></tr>`).join("")}</tbody></table><button data-act="add" data-list="${key}"><i class="fa-solid fa-plus"></i> Add</button></div>`;
    switch (this.tab) {
      case "stats": return `<div class="ms-cfg-sec"><h3>Stats</h3><p class="hint">Add, rename, reorder or remove stats. Each has an icon (Font Awesome class), a color, bounds, a cost multiplier (when stats are paid) and an optional seal (locked until the GM unseals it on a character).</p>
        <table class="ms-cfg-table"><thead><tr><th>Name</th><th>Abbr.</th><th>Icon</th><th>Color</th><th>Min</th><th>Max</th><th>Cost ×</th><th>Sealed</th><th>Key</th><th></th></tr></thead><tbody>${c.stats.map((s, i) => `<tr style="--sc:${esc(s.color)}"><td>${inp(`stats.${i}.name`, s.name)}</td><td class="w70">${inp(`stats.${i}.abbr`, s.abbr)}</td><td class="icon"><i class="fa-solid ${esc(s.icon)}"></i>${inp(`stats.${i}.icon`, s.icon, "text", 'placeholder="fa-…"')}</td><td>${color(`stats.${i}.color`, s.color)}</td><td class="w60">${inp(`stats.${i}.min`, s.min, "number")}</td><td class="w60">${inp(`stats.${i}.max`, s.max, "number")}</td><td class="w60">${inp(`stats.${i}.costMult`, s.costMult, "number", 'step="0.1"')}</td><td>${chk(`stats.${i}.locked`, s.locked, "")}</td><td><code>${esc(s.key)}</code></td><td>${rowBtns("stats", i, c.stats.length)}</td></tr>`).join("")}</tbody></table>
        <button data-act="add" data-list="stats"><i class="fa-solid fa-plus"></i> Add a stat</button>
        <h3>Color behavior</h3><label class="ms-f"><span>The stat color tints</span><select data-path="statColorMode"><option value="card"${c.statColorMode === "card" ? " selected" : ""}>the whole card</option><option value="number"${c.statColorMode === "number" ? " selected" : ""}>the number only</option><option value="watermark"${c.statColorMode === "watermark" ? " selected" : ""}>the watermark icon only</option></select></label>
        <p class="hint">Icons: any Font Awesome Free solid class, e.g. <code>fa-hand-fist</code>, <code>fa-bolt</code>, <code>fa-eye</code>. Full list at fontawesome.com (Free, Solid).</p></div>`;
      case "resources": return `<div class="ms-cfg-sec"><h3>Currencies & resources</h3><p class="hint">Gold, coins, points, karma… Any number the sheet tracks. One of them can pay for stats (Progression settings).</p>
        <table class="ms-cfg-table"><thead><tr><th>Name</th><th>Icon</th><th>Color</th><th>Start</th><th>Min</th><th>In header</th><th>Key</th><th></th></tr></thead><tbody>${c.resources.map((r, i) => `<tr><td>${inp(`resources.${i}.name`, r.name)}</td><td class="icon"><i class="fa-solid ${esc(r.icon)}"></i>${inp(`resources.${i}.icon`, r.icon)}</td><td>${color(`resources.${i}.color`, r.color)}</td><td class="w70">${inp(`resources.${i}.start`, r.start, "number")}</td><td class="w70">${inp(`resources.${i}.min`, r.min, "number")}</td><td>${chk(`resources.${i}.inHeader`, r.inHeader, "")}</td><td><code>${esc(r.key)}</code></td><td>${rowBtns("resources", i, c.resources.length)}</td></tr>`).join("")}</tbody></table><button data-act="add" data-list="resources"><i class="fa-solid fa-plus"></i> Add a currency</button></div>`;
      case "ranks": return `${simpleList("ranks", "Rank ladder", "From weakest to strongest. Used by characters and items.", ["Name", "Color", "Key"])}
        <div class="ms-cfg-sec"><h3>Rank color behavior</h3><p class="hint">Where the rank color shows up.</p><div class="ms-chips">${[["badge", "Rank badge"], ["name", "Item name"], ["row", "Row border"], ["glow", "Glow"], ["hex", "Sheet hexagon"]].map(x => `<label class="ms-chip${c.rankColor.targets.includes(x[0]) ? " on" : ""}"><input type="checkbox" data-act="toggleTarget" data-v="${x[0]}"${c.rankColor.targets.includes(x[0]) ? " checked" : ""}>${x[1]}</label>`).join("")}</div>
        <label class="ms-f"><span>Intensity</span><input type="range" data-path="rankColor.intensity" min="0.3" max="1.5" step="0.1" value="${c.rankColor.intensity}"><output>${c.rankColor.intensity}</output></label>
        ${chk("rankColor.rarityOwnColor", c.rankColor.rarityOwnColor, "Rarity uses its own color (otherwise it follows the rank)")}</div>`;
      case "states": return `${simpleList("awakening", "Awakening states", "Unawakened, Awakened, Transcended… or classes, cultivation realms, hunter licenses.", ["Name", "Color", "Key"])}${simpleList("origins", "Origins", "Worlds, regions, nations, factions of origin. Empty = the Origin field is hidden on the sheet.", ["Name", "Color", "Key"])}`;
      case "lists": return simpleList("rarities", "Rarities", "", ["Name", "Color", "Key"]) + simpleList("elements", "Elements", "", ["Name", "Color", "Key"]) + simpleList("costs", "Skill costs", "", ["Name", "Key"]) + simpleList("ranges", "Ranges", "", ["Name", "Key"]) + simpleList("executions", "Executions", "", ["Name", "Key"]);
      case "items": return this.itemsTab();
      case "identity": return this.identityTab();
    }
  }
  itemsTab() {
    const c = this.cfg; const nodes = flattenTree(c.items);
    const fieldChips = (n) => { const own = n.fields || []; const inherited = !own.length; return `<div class="ms-chips small ${inherited ? "inherited" : ""}" title="${inherited ? "Inherits the parent's fields — tick one to define its own set" : "Own field set"}">${Object.entries(ITEM_FIELDS).map(([k, d]) => `<label class="ms-chip${(inherited ? this.effFields(n) : own).includes(k) ? " on" : ""}"><input type="checkbox" data-act="toggleField" data-node="${n.id}" data-f="${k}"${(inherited ? this.effFields(n) : own).includes(k) ? " checked" : ""}>${d.label}</label>`).join("")}${!inherited && n.parent ? `<a data-act="inheritFields" data-node="${n.id}" class="ms-inh">inherit from parent</a>` : ""}</div>`; };
    const rows = nodes.map(n => `<div class="ms-node d${n.depth}" style="--rc:${esc(n.color || n.parent?.color || "#38a8ff")}"><div class="ms-node-row"><i class="fa-solid ${esc(n.icon || "fa-folder")}"></i><input type="text" data-act="nodeName" data-node="${n.id}" value="${esc(n.name)}"><input type="text" class="ic" data-act="nodeIcon" data-node="${n.id}" value="${esc(n.icon || "")}" placeholder="fa-…">${n.depth === 0 ? `<input type="color" data-act="nodeColor" data-node="${n.id}" value="${esc(n.color || "#38a8ff")}">` : ""}<span class="ms-rb"><a data-act="nodeAdd" data-node="${n.id}" title="Add a sub-category"><i class="fa-solid fa-plus"></i></a><a data-act="nodeUp" data-node="${n.id}"><i class="fa-solid fa-chevron-up"></i></a><a data-act="nodeDown" data-node="${n.id}"><i class="fa-solid fa-chevron-down"></i></a><a data-act="nodeDel" data-node="${n.id}" class="danger" title="${n.children?.length ? "Remove sub-categories first" : "Delete"}"><i class="fa-solid fa-xmark"></i></a></span></div>${fieldChips(n)}</div>`).join("");
    return `<div class="ms-cfg-sec"><h3>Item categories</h3><p class="hint">A tree of any depth. Top level = tabs on the sheet; second level = sub-tabs; deeper levels group items. Each node has a field set (ticked chips) inherited by its children unless they tick their own. Items point to a leaf.</p>
      <div class="ms-tree">${rows}</div><button data-act="nodeAddRoot"><i class="fa-solid fa-plus"></i> Add a top-level category</button>
      <h3>Equipped on body</h3><p class="hint">Off by default. When on, equippable items get a shield button: equipped items stay in the inventory and also appear in an « Equipped » tab.</p>${chk("equipment.enabled", c.equipment.enabled, "Enable the Equipped tab")} <label class="ms-f"><span>Slots (0 = unlimited)</span>${inp("equipment.slots", c.equipment.slots, "number")}</label></div>`;
  }
  effFields(n) { let x = n; while (x) { if (x.fields?.length) return x.fields; x = x.parent; } return []; }
  identityTab() {
    const c = this.cfg;
    return `<div class="ms-cfg-sec"><h3>Identity sections</h3><p class="hint">Sub-tabs of the Identity tab, each with its fields: short text, long text, number or choice list (options comma-separated).</p>
      ${c.identity.map((s, si) => `<div class="ms-sec"><div class="ms-sec-h"><input type="text" data-path="identity.${si}.name" value="${esc(s.name)}">${rowBtns("identity", si, c.identity.length)}</div>
        <table class="ms-cfg-table"><thead><tr><th>Label</th><th>Kind</th><th>Options</th><th>Key</th><th></th></tr></thead><tbody>${s.fields.map((f, fi) => `<tr><td>${inp(`identity.${si}.fields.${fi}.label`, f.label)}</td><td><select data-path="identity.${si}.fields.${fi}.kind">${[["short", "Short text"], ["rich", "Long text"], ["number", "Number"], ["select", "Choice"]].map(k => `<option value="${k[0]}"${f.kind === k[0] ? " selected" : ""}>${k[1]}</option>`).join("")}</select></td><td>${f.kind === "select" ? `<input type="text" data-path="identity.${si}.fields.${fi}.options" data-list="1" value="${esc((f.options || []).join(", "))}" placeholder="A, B, C">` : ""}</td><td><code>${esc(f.key)}</code></td><td>${rowBtns(`identity.${si}.fields`, fi, s.fields.length)}</td></tr>`).join("")}</tbody></table><button data-act="addField" data-si="${si}"><i class="fa-solid fa-plus"></i> Add a field</button></div>`).join("")}
      <button data-act="add" data-list="identity"><i class="fa-solid fa-plus"></i> Add a section</button></div>`;
  }
  onChanged(path, el) { if (el.type === "range") { el.nextElementSibling.textContent = el.value; return; } if (el.type === "text" || el.type === "number" || el.type === "color") { this.element.querySelector(".ms-cfg-foot span").className = "dirty"; return; } this.render(); }
  async extraAct(act, a) {
    const c = this.cfg; const nodes = flattenTree(c.items); const node = a.dataset.node ? nodes.find(n => n.id === a.dataset.node) : null; const real = node ? this.realNode(node.id) : null; const siblings = node ? (node.parent ? this.realNode(node.parent.id).children : c.items) : null;
    if (act === "add") { const list = this.listAt(a.dataset.list); const name = await ask("New entry", "Name"); if (!name) return; const key = slug(name); if (list.some(x => x.key === key)) return ui.notifications.warn("This key already exists."); const base = { key, name };
      if (a.dataset.list === "stats") Object.assign(base, { abbr: name.slice(0, 4).toUpperCase(), icon: "fa-star", color: "#38a8ff", min: 1, max: 99, costMult: 1, locked: false });
      else if (a.dataset.list === "resources") Object.assign(base, { icon: "fa-coins", color: "#ffd070", start: 0, min: 0, inHeader: true, paysStats: false });
      else if (a.dataset.list === "identity") Object.assign(base, { fields: [] }); else base.color = "#38a8ff";
      list.push(base); this.dirty = true; }
    else if (act === "addField") { const s = c.identity[Number(a.dataset.si)]; const label = await ask("New field", "Label"); if (!label) return; s.fields.push({ key: slug(label), label, kind: "short" }); this.dirty = true; }
    else if (act === "toggleTarget") { const v = a.dataset.v; const t = c.rankColor.targets; c.rankColor.targets = t.includes(v) ? t.filter(x => x !== v) : [...t, v]; this.dirty = true; }
    else if (act === "toggleField" && real) { const f = a.dataset.f; let own = real.fields?.length ? [...real.fields] : [...this.effFields(node)]; own = own.includes(f) ? own.filter(x => x !== f) : [...own, f]; real.fields = own; this.dirty = true; }
    else if (act === "inheritFields" && real) { delete real.fields; this.dirty = true; }
    else if (act === "nodeName" && real) { real.name = a.value; this.dirty = true; return; }
    else if (act === "nodeIcon" && real) { real.icon = a.value; this.dirty = true; return; }
    else if (act === "nodeColor" && real) { real.color = a.value; this.dirty = true; return; }
    else if (act === "nodeAdd" && real) { const name = await ask("New sub-category", "Name"); if (!name) return; real.children ||= []; real.children.push({ id: slug(name) + "_" + uid().slice(0, 4), name, icon: "fa-folder", children: [] }); this.dirty = true; }
    else if (act === "nodeAddRoot") { const name = await ask("New top-level category", "Name"); if (!name) return; c.items.push({ id: slug(name) + "_" + uid().slice(0, 4), name, icon: "fa-folder", color: "#38a8ff", fields: ["rank", "rarity", "quantity", "value", "lore"], children: [] }); this.dirty = true; }
    else if ((act === "nodeUp" || act === "nodeDown") && real) { const i = siblings.indexOf(real), j = act === "nodeUp" ? i - 1 : i + 1; if (j < 0 || j >= siblings.length) return; [siblings[i], siblings[j]] = [siblings[j], siblings[i]]; this.dirty = true; }
    else if (act === "nodeDel" && real) { if (real.children?.length) return ui.notifications.warn("Remove its sub-categories first."); siblings.splice(siblings.indexOf(real), 1); this.dirty = true; }
  }
  realNode(id) { const walk = arr => { for (const n of arr || []) { if (n.id === id) return n; const r = walk(n.children); if (r) return r; } return null; }; return walk(this.cfg.items); }
}

/* ═══════════ Progression & costs ═══════════ */
export class ProgressionApp extends BaseConfigApp {
  static DEFAULT_OPTIONS = { id: "ms-progression", window: { title: "Manhwa Sheet — Progression & costs", icon: "fa-solid fa-arrow-trend-up" }, position: { width: 900, height: 720 } };
  static TABS = [["paid", "Paid stats", "fa-coins"], ["caps", "Caps & tiers", "fa-layer-group"], ["messages", "Messages", "fa-message"]];
  static RESET = { paid: ["progression.paidStats", "progression.payWith", "progression.refundOnLower", "progression.costMode", "progression.tiers", "progression.multiplier", "progression.manual"], caps: ["progression.capPerStat", "progression.capTotal", "progression.tierEvery", "progression.tierNames"], messages: ["progression.messages"] };
  body() {
    const c = this.cfg, p = c.progression;
    if (this.tab === "paid") {
      const res = c.resources.map(r => `<option value="${esc(r.key)}"${r.key === p.payWith ? " selected" : ""}>${esc(r.name)}</option>`).join("");
      const modes = [["tiers", "By tiers", "One line per value range: « from 11 to 30, each point costs 250 ». The simplest."], ["multiplier", "By formula", "Base cost + increase per point already owned. Smooth curve."], ["manual", "One by one", "A cost for every single value, editable individually (start from the tiers)."]];
      const modeSel = `<div class="ms-modes">${modes.map(m => `<label class="ms-mode${p.costMode === m[0] ? " on" : ""}"><input type="radio" name="costMode" data-path="progression.costMode" value="${m[0]}"${p.costMode === m[0] ? " checked" : ""}><b>${m[1]}</b><small>${m[2]}</small></label>`).join("")}</div>`;
      let editor = "";
      if (p.costMode === "tiers") editor = `<table class="ms-cfg-table tiers"><thead><tr><th>From value</th><th>To value</th><th>Cost of one point</th><th></th></tr></thead><tbody>${p.tiers.map((t, i) => `<tr><td>${inp(`progression.tiers.${i}.from`, t.from, "number")}</td><td>${inp(`progression.tiers.${i}.to`, t.to, "number")}</td><td>${inp(`progression.tiers.${i}.cost`, t.cost, "number")}</td><td>${rowBtns("progression.tiers", i, p.tiers.length)}</td></tr>`).join("")}</tbody></table><button data-act="addTier"><i class="fa-solid fa-plus"></i> Add a tier</button>`;
      else if (p.costMode === "multiplier") editor = `<div class="ms-row"><label class="ms-f"><span>Base cost (first point)</span>${inp("progression.multiplier.base", p.multiplier.base, "number")}</label><label class="ms-f"><span>Increase per point owned</span>${inp("progression.multiplier.perPoint", p.multiplier.perPoint, "number")}</label></div><p class="hint">Cost to go from value v to v+1 = base + increase × (v − 1). Example: 100 + 25 × (v − 1) → 100, 125, 150…</p>`;
      else editor = `<p class="hint">Cost of each step (value → value + 1). <a data-act="fillManual">Fill from the tiers</a> then adjust.</p><div class="ms-manual">${Array.from({ length: 99 }, (_, i) => i + 1).map(v => `<label><span>${v} → ${v + 1}</span>${inp(`progression.manual.${v}`, p.manual[v] ?? "", "number")}</label>`).join("")}</div>`;
      const st = c.stats[0]; const prev = [10, 20, 50, 99].map(v => `<span>1 → ${v} : <b>${fmt(costBetween(c, 1, v, { costMult: 1 }))}</b></span>`).join("");
      return `<div class="ms-cfg-sec"><h3>Paid stats</h3>${chk("progression.paidStats", p.paidStats, "Stats cost a resource (off: the − / + buttons change values freely)")}
        <div class="ms-row"><label class="ms-f"><span>Paid with</span><select data-path="progression.payWith">${res}</select></label>${chk("progression.refundOnLower", p.refundOnLower, "Lowering a stat refunds the last point")}</div>
        <h3>Cost model</h3>${modeSel}<div class="ms-editor">${editor}</div>
        <div class="ms-preview"><i class="fa-solid fa-calculator"></i> Cumulative cost (×1 stat) ${prev}<small>Each stat can have its own multiplier (Sheet configuration → Stats). Next step for a value of 12: <b>${fmt(costOfStep(c, 12, { costMult: 1 }))}</b>.</small></div></div>`;
    }
    if (this.tab === "caps") return `<div class="ms-cfg-sec"><h3>Caps</h3><div class="ms-row"><label class="ms-f"><span>Max per stat (0 = each stat's own max)</span>${inp("progression.capPerStat", p.capPerStat, "number")}</label><label class="ms-f"><span>Max total of all stats (0 = none)</span>${inp("progression.capTotal", p.capTotal, "number")}</label></div>
      <h3>Tiers (titles shown on the card)</h3><div class="ms-row"><label class="ms-f"><span>A tier every N values (0 = off)</span>${inp("progression.tierEvery", p.tierEvery, "number")}</label><label class="ms-f grow"><span>Tier names, comma-separated</span><input type="text" data-path="progression.tierNames" data-list="1" value="${esc(p.tierNames.join(", "))}"></label></div></div>`;
    return `<div class="ms-cfg-sec"><h3>Messages</h3><p class="hint">Shown when an action is refused. {resource} = the paying resource's name.</p>${[["locked", "Sealed stat"], ["cap", "Stat cap reached"], ["total", "Total cap reached"], ["broke", "Not enough resource"]].map(m => `<label class="ms-f wide"><span>${m[1]}</span>${inp(`progression.messages.${m[0]}`, p.messages[m[0]])}</label>`).join("")}</div>`;
  }
  onChanged(path, el) { if (el.type === "radio" || el.type === "checkbox" || el.type === "select-one") return this.render(); if (path.startsWith("progression.tiers") || path.startsWith("progression.multiplier") || path.startsWith("progression.manual")) { const prev = this.element.querySelector(".ms-preview"); if (prev) { const c = this.cfg; prev.innerHTML = `<i class="fa-solid fa-calculator"></i> Cumulative cost (×1 stat) ${[10, 20, 50, 99].map(v => `<span>1 → ${v} : <b>${fmt(costBetween(c, 1, v, { costMult: 1 }))}</b></span>`).join("")}<small>Next step for a value of 12: <b>${fmt(costOfStep(c, 12, { costMult: 1 }))}</b>.</small>`; } } this.element.querySelector(".ms-cfg-foot span").className = "dirty"; }
  async extraAct(act) { const p = this.cfg.progression; if (act === "addTier") { const last = p.tiers[p.tiers.length - 1]; p.tiers.push({ from: (last?.to || 0) + 1, to: (last?.to || 0) + 10, cost: last ? last.cost * 2 : 100 }); this.dirty = true; } else if (act === "fillManual") { p.manual = []; for (let v = 1; v <= 99; v++) { const t = p.tiers.find(x => v >= x.from && v <= x.to); p.manual[v] = t ? t.cost : (p.tiers[p.tiers.length - 1]?.cost || 0); } this.dirty = true; } }
}

async function ask(title, label) { const r = await DialogV2.prompt({ window: { title }, classes: ["ms-dialog"], content: `<div class="ms-form"><label>${esc(label)}<input type="text" name="v" autofocus></label></div>`, ok: { label: "OK", callback: (ev, btn) => btn.form.elements.v.value.trim() } }); return r || null; }

/* Manhwa Sheet — system entry point */
import { SYS, THEMES, DEFAULT_CONFIG, getConfig, applyTheme, costOfStep, costBetween } from "./config.js";
import { CharacterData, NpcData, ItemData } from "./data-models.js";
import { CharacterSheet } from "./sheet-character.js";
import { ManhwaItemSheet } from "./sheet-item.js";
import { SheetConfigApp, ProgressionApp } from "./app-config.js";

globalThis.MANHWA = { config: () => { try { return getConfig(); } catch (e) { return foundry.utils.deepClone(DEFAULT_CONFIG); } }, costOfStep, costBetween };

Hooks.once("init", () => {
  CONFIG.Actor.dataModels.character = CharacterData; CONFIG.Actor.dataModels.npc = NpcData; CONFIG.Item.dataModels.item = ItemData;
  const Actors = foundry.documents.collections.Actors, Items = foundry.documents.collections.Items;
  try { const AS = foundry.appv1?.sheets?.ActorSheet ?? globalThis.ActorSheet, IS = foundry.appv1?.sheets?.ItemSheet ?? globalThis.ItemSheet; if (AS) Actors.unregisterSheet("core", AS); if (IS) Items.unregisterSheet("core", IS); } catch (e) { console.warn(SYS, e); }
  Actors.registerSheet(SYS, CharacterSheet, { types: ["character", "npc"], makeDefault: true, label: "Manhwa Sheet" });
  Items.registerSheet(SYS, ManhwaItemSheet, { types: ["item"], makeDefault: true, label: "Manhwa Item" });

  game.settings.register(SYS, "config", { scope: "world", config: false, type: Object, default: DEFAULT_CONFIG });
  game.settings.registerMenu(SYS, "configMenu", { name: "MANHWA.Settings.Config", label: "MANHWA.Settings.ConfigLabel", hint: "MANHWA.Settings.ConfigHint", icon: "fa-solid fa-sliders", type: SheetConfigApp, restricted: true });
  game.settings.registerMenu(SYS, "progressionMenu", { name: "MANHWA.Settings.Progression", label: "MANHWA.Settings.ProgressionLabel", hint: "MANHWA.Settings.ProgressionHint", icon: "fa-solid fa-arrow-trend-up", type: ProgressionApp, restricted: true });
  game.settings.register(SYS, "theme", { name: "MANHWA.Settings.Theme", hint: "MANHWA.Settings.ThemeHint", scope: "world", config: true, type: String, choices: THEMES, default: "solo-neon", onChange: () => { applyTheme(); rerenderAll(); } });
  game.settings.register(SYS, "anim", { name: "MANHWA.Settings.Anim", hint: "MANHWA.Settings.AnimHint", scope: "client", config: true, type: String, choices: { full: "Full", low: "Low", off: "Off" }, default: "low", onChange: applyTheme });
  game.settings.register(SYS, "playersCanLower", { name: "MANHWA.Settings.PlayersCanLower", scope: "world", config: true, type: Boolean, default: true });
  game.settings.register(SYS, "gmFree", { name: "MANHWA.Settings.GmFree", scope: "world", config: true, type: Boolean, default: true });
});

function rerenderAll() { for (const app of foundry.applications.instances.values()) if (app.actor || app.item) app.render(); }
Hooks.once("ready", () => { applyTheme(); });
Hooks.on("updateSetting", s => { if (s.key === `${SYS}.config`) { for (const a of game.actors) a.reset(); rerenderAll(); } });

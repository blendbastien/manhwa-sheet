/* Manhwa Sheet — character sheet (AppV2, rendered from the world configuration) */
import { SYS, esc, getConfig, costOfStep, rankOf, flattenTree, fieldsOf, rootOf, ITEM_FIELDS } from "./config.js";

const { ActorSheetV2 } = foundry.applications.sheets;

/* portrait framing presets (same as the former sheet: a bar under the portrait) */
export const POS = [["center", "Center"], ["top", "Top"], ["bottom", "Bottom"], ["left", "Left"], ["right", "Right"], ["topleft", "Top left"], ["topright", "Top right"], ["bottomleft", "Bottom left"], ["bottomright", "Bottom right"], ["contain", "Whole image"], ["zoom", "Zoom ×1.5 center"], ["zoomtop", "Zoom ×1.5 top"], ["zoombottom", "Zoom ×1.5 bottom"], ["zoom2", "Zoom ×2 center"], ["zoom2top", "Zoom ×2 top"], ["zoom3top", "Zoom ×3 top (face)"]];
export const POS_CSS = { center: ["cover", "center center", 1], top: ["cover", "center top", 1], bottom: ["cover", "center bottom", 1], left: ["cover", "left center", 1], right: ["cover", "right center", 1], topleft: ["cover", "left top", 1], topright: ["cover", "right top", 1], bottomleft: ["cover", "left bottom", 1], bottomright: ["cover", "right bottom", 1], contain: ["contain", "center center", 1], zoom: ["cover", "center center", 1.5], zoomtop: ["cover", "center 15%", 1.5], zoombottom: ["cover", "center 85%", 1.5], zoom2: ["cover", "center center", 2], zoom2top: ["cover", "center 12%", 2], zoom3top: ["cover", "center 10%", 3] };
export function portraitStyle(pos) { const c = POS_CSS[pos] || POS_CSS.center; return `object-fit:${c[0]};object-position:${c[1]};${c[2] !== 1 ? `transform:scale(${c[2]});transform-origin:${c[1]};` : ""}`; }

const sel = (name, opts, cur, extra = "") => `<select name="${name}" ${extra}>${opts.map(o => `<option value="${esc(o.key)}"${o.key === cur ? " selected" : ""}>${esc(o.name)}</option>`).join("")}</select>`;
const fmt = n => new Intl.NumberFormat("en-US").format(Number(n) || 0);

export class CharacterSheet extends ActorSheetV2 {
  static DEFAULT_OPTIONS = {
    classes: ["ms-sheet", "ms-character"], position: { width: 980, height: 820 }, window: { resizable: true, icon: "fa-solid fa-id-card" },
    form: { submitOnChange: true, closeOnSubmit: false },
    actions: { statPlus: CharacterSheet.#stat, statMinus: CharacterSheet.#stat, tab: CharacterSheet.#tab, sub: CharacterSheet.#sub, itemCreate: CharacterSheet.#itemCreate, itemEdit: CharacterSheet.#itemEdit, itemDelete: CharacterSheet.#itemDelete, itemEquip: CharacterSheet.#itemEquip, itemQty: CharacterSheet.#itemQty, equipTitle: CharacterSheet.#equipTitle, unlockStat: CharacterSheet.#unlockStat }
  };
  constructor(...a) { super(...a); this.tab = "stats"; this.sub = {}; }
  get title() { return this.actor.name; }

  /* ───────── render ───────── */
  async _renderHTML() {
    const a = this.actor, s = a.system, cfg = getConfig(), gm = game.user.isGM, editable = this.isEditable;
    const p = cfg.progression; const payRes = cfg.resources.find(r => r.key === p.payWith) || cfg.resources[0];
    /* header */
    const resources = cfg.resources.filter(r => r.inHeader).map(r => `<label class="ms-res" style="--c:${esc(r.color)}"><i class="fa-solid ${esc(r.icon)}"></i><span>${esc(r.name)}</span><input type="number" name="system.resources.${r.key}" value="${Number(s.resources[r.key]) || 0}" min="${r.min ?? 0}" ${editable ? "" : "disabled"}></label>`).join("");
    const title = a.items.get(s.equippedTitle);
    const originSel = cfg.origins.length ? `<label class="ms-f"><span>Origin</span>${sel("system.origin", [{ key: "", name: "—" }, ...cfg.origins], s.origin)}</label>` : "";
    const header = `<header class="ms-head">
      <div class="ms-portrait"><div class="ms-pic"><img src="${esc(a.img)}" data-action="editImage" data-edit="img" style="${portraitStyle(s.portrait)}" title="Click to change the portrait"></div><div class="ms-lv"><small>LV</small>${s.level}</div>
        <div class="ms-frame-bar"><i class="fa-solid fa-crop-simple"></i><select name="system.portrait" title="Portrait framing">${POS.map(x => `<option value="${x[0]}"${x[0] === s.portrait ? " selected" : ""}>${x[1]}</option>`).join("")}</select></div></div>
      <div class="ms-idblock">
        <input class="ms-name" type="text" name="name" value="${esc(a.name)}" placeholder="Name" ${editable ? "" : "disabled"}>
        <div class="ms-row">
          <label class="ms-f num"><span>Level</span><input type="number" name="system.level" value="${s.level}" min="0"></label>
          <label class="ms-f"><span>Awakening</span>${sel("system.awakening", cfg.awakening, s.awakening)}</label>
          <label class="ms-f rank" style="--rc:${esc(rankOf(cfg, s.rank)?.color || "#fff")}"><span>Rank</span>${sel("system.rank", cfg.ranks, s.rank)}</label>
          ${originSel}
          <label class="ms-f grow"><span>Sponsor</span><input type="text" name="system.sponsor" value="${esc(s.sponsor)}" placeholder="—"></label>
        </div>
        <div class="ms-row ms-resources">${resources}
          <div class="ms-title-eq"><i class="fa-solid fa-crown"></i><span>Title</span><b>${title ? esc(title.name) : "<em>none equipped</em>"}</b></div>
        </div>
      </div></header>`;
    /* tabs */
    const roots = cfg.items;
    const tabs = [["stats", "Stats", "fa-chart-simple"], ["identity", "Identity", "fa-id-card"], ...roots.map(r => [r.id, r.name, r.icon])];
    if (cfg.equipment.enabled) tabs.push(["equipped", "Equipped", "fa-user-shield"]);
    const nav = `<nav class="ms-tabs">${tabs.map(t => `<a data-action="tab" data-tab="${t[0]}" class="${this.tab === t[0] ? "on" : ""}"><i class="fa-solid ${t[2]}"></i>${esc(t[1])}</a>`).join("")}</nav>`;
    let body = "";
    if (this.tab === "stats") body = this.#statsHTML(cfg, s, gm, editable, payRes);
    else if (this.tab === "identity") body = this.#identityHTML(cfg, s, editable);
    else if (this.tab === "equipped") body = this.#equippedHTML(cfg, editable);
    else body = this.#itemsHTML(cfg, this.tab, editable);
    return `<div class="ms-wrap">${header}${nav}<section class="ms-body">${body}</section></div>`;
  }
  _replaceHTML(result, content) { content.innerHTML = result; }

  #statsHTML(cfg, s, gm, editable, payRes) {
    const p = cfg.progression; const paid = p.paidStats; const total = s.statsTotal || 0;
    const cards = cfg.stats.map(st => {
      const v = Number(s.stats[st.key]) || st.min || 0; const locked = st.locked && !s.statsUnlocked?.[st.key];
      const capped = (p.capPerStat && v >= p.capPerStat) || (st.max && v >= st.max) || (p.capTotal && total >= p.capTotal);
      const cost = paid ? costOfStep(cfg, v, st) : 0; const funds = Number(s.resources[payRes?.key]) || 0; const broke = paid && !gm && cost > funds;
      const tier = p.tierEvery ? p.tierNames[Math.min(p.tierNames.length - 1, Math.floor((v - 1) / p.tierEvery))] : "";
      return `<div class="ms-stat mode-${cfg.statColorMode}${locked ? " locked" : ""}${capped ? " capped" : ""}" style="--sc:${esc(st.color)}" data-stat="${st.key}">
        <div class="ms-stat-h"><i class="fa-solid ${esc(st.icon)}"></i><span>${esc(st.name)}</span><small>${esc(st.abbr)}</small>${tier ? `<em class="tier">${esc(tier)}</em>` : ""}</div>
        <i class="ms-stat-wm fa-solid ${esc(st.icon)}"></i>
        <div class="ms-stat-v">
          <button type="button" class="ms-pm" data-action="statMinus" ${!editable || locked || v <= (st.min ?? 0) || (!gm && !game.settings.get(SYS, "playersCanLower")) ? "disabled" : ""} title="${paid && p.refundOnLower ? `Refund ${fmt(costOfStep(cfg, v - 1, st))} ${esc(payRes?.name || "")}` : "Lower"}"><i class="fa-solid fa-minus"></i></button>
          <input type="number" name="system.stats.${st.key}" value="${v}" ${gm && editable ? "" : "readonly"}>
          <button type="button" class="ms-pm plus${broke ? " broke" : ""}" data-action="statPlus" ${!editable || locked || capped ? "disabled" : ""} title="${locked ? esc(p.messages.locked) : capped ? esc(p.messages.cap) : paid ? `Next point: ${fmt(cost)} ${esc(payRes?.name || "")}` : "Raise"}"><i class="fa-solid fa-plus"></i></button>
        </div>
        ${paid && !locked && !capped ? `<div class="ms-stat-cost">${fmt(cost)} <i class="fa-solid ${esc(payRes?.icon || "fa-coins")}"></i></div>` : ""}
        ${locked ? `<div class="ms-stat-lock"><i class="fa-solid fa-lock"></i> SEALED${gm ? ` <a data-action="unlockStat" title="Unseal for this character">unseal</a>` : ""}</div>` : ""}
      </div>`;
    }).join("");
    return `<div class="ms-stats">${cards}</div><div class="ms-stats-foot"><span>Total <b>${total}</b>${p.capTotal ? ` / ${p.capTotal}` : ""}</span>${paid ? `<span>Paid with <b style="color:${esc(payRes?.color || "#fff")}">${esc(payRes?.name || "")}</b> · ${fmt(s.resources[payRes?.key] || 0)} available</span>` : `<span class="dim">Free progression</span>`}</div>`;
  }
  #identityHTML(cfg, s, editable) {
    const cur = this.sub.identity || cfg.identity[0]?.key; const sec = cfg.identity.find(x => x.key === cur) || cfg.identity[0]; if (!sec) return `<div class="ms-empty">No identity sections configured.</div>`;
    const nav = `<nav class="ms-subtabs">${cfg.identity.map((x, i) => `<a data-action="sub" data-group="identity" data-sub="${x.key}" class="${x.key === sec.key ? "on" : ""}">${i + 1}. ${esc(x.name)}</a>`).join("")}</nav>`;
    const val = f => s.identity?.[sec.key]?.[f.key] ?? "";
    const fields = sec.fields.map(f => { const n = `system.identity.${sec.key}.${f.key}`; const v = val(f);
      if (f.kind === "rich") return `<label class="ms-f wide"><span>${esc(f.label)}</span><textarea name="${n}" rows="4" placeholder="…">${esc(v)}</textarea></label>`;
      if (f.kind === "number") return `<label class="ms-f"><span>${esc(f.label)}</span><input type="number" name="${n}" value="${esc(v)}"></label>`;
      if (f.kind === "select") return `<label class="ms-f"><span>${esc(f.label)}</span><select name="${n}"><option value="">—</option>${(f.options || []).map(o => `<option${o === v ? " selected" : ""}>${esc(o)}</option>`).join("")}</select></label>`;
      return `<label class="ms-f"><span>${esc(f.label)}</span><input type="text" name="${n}" value="${esc(v)}" placeholder="${esc(f.label)}…"></label>`; }).join("");
    return `${nav}<div class="ms-card"><div class="ms-grid2">${fields}</div></div>`;
  }
  #itemsHTML(cfg, rootId, editable) {
    const root = cfg.items.find(r => r.id === rootId); if (!root) return "";
    const nodes = flattenTree([root]); const leaves = nodes.filter(n => !n.children?.length);
    const items = this.actor.items.filter(i => nodes.some(n => n.id === i.system.category));
    const subs = root.children?.length ? `<nav class="ms-subtabs">${[{ id: "", name: "All" }, ...root.children].map(c => `<a data-action="sub" data-group="${root.id}" data-sub="${c.id}" class="${(this.sub[root.id] || "") === c.id ? "on" : ""}">${esc(c.name)}</a>`).join("")}</nav>` : "";
    const curSub = this.sub[root.id] || ""; const subNodes = curSub ? flattenTree([root.children.find(c => c.id === curSub)]) : nodes;
    const shown = items.filter(i => subNodes.some(n => n.id === i.system.category)).sort((a, b) => a.name.localeCompare(b.name));
    const fields = fieldsOf(cfg, curSub || root.id).filter(f => f !== "lore" && f !== "equippable");
    const cols = fields.map(f => `<th class="c-${f}">${esc(ITEM_FIELDS[f]?.label || f)}</th>`).join("");
    const rows = shown.map(i => { const r = rankOf(cfg, i.system.rank); const rar = cfg.rarities.find(x => x.key === i.system.rarity); const node = nodes.find(n => n.id === i.system.category);
      const cells = fields.map(f => { const v = i.system[f]; let t = esc(v ?? "");
        if (f === "rank") t = `<span class="ms-rank" style="--rc:${esc(r?.color || "#fff")}">${esc(r?.name || v || "—")}</span>`;
        else if (f === "rarity") t = `<span class="ms-rar" style="--rc:${esc(rar?.color || "#8ea0c8")}">${esc(rar?.name || v || "—")}</span>`;
        else if (f === "quantity") t = `<span class="ms-qty"><a data-action="itemQty" data-d="-1"><i class="fa-solid fa-minus"></i></a><b>${Number(v) || 0}</b><a data-action="itemQty" data-d="1"><i class="fa-solid fa-plus"></i></a></span>`;
        else if (f === "value") t = fmt(v);
        else if (ITEM_FIELDS[f]?.kind === "list") t = esc((cfg[ITEM_FIELDS[f].list] || []).find(x => x.key === v)?.name || v || "—");
        return `<td class="c-${f}">${t}</td>`; }).join("");
      const eq = cfg.equipment.enabled && (i.system.equippable || root.id === "titles") ? `<a data-action="${root.id === "titles" ? "equipTitle" : "itemEquip"}" class="eq${(root.id === "titles" ? this.actor.system.equippedTitle === i.id : i.system.equipped) ? " on" : ""}" title="${root.id === "titles" ? "Equip this title" : "Equipped on body (stays in inventory)"}"><i class="fa-solid ${root.id === "titles" ? "fa-crown" : "fa-user-shield"}"></i></a>` : (root.id === "titles" ? `<a data-action="equipTitle" class="eq${this.actor.system.equippedTitle === i.id ? " on" : ""}" title="Equip this title"><i class="fa-solid fa-crown"></i></a>` : "");
      return `<tr data-item="${i.id}" class="${i.system.fx ? "fx-" + esc(i.system.fx) : ""}"><td class="c-name"><img src="${esc(i.img)}"><a data-action="itemEdit"><b>${esc(i.name)}</b></a><small>${esc(node?.name || "")}</small></td>${cells}<td class="c-act">${eq}<a data-action="itemEdit" title="Edit"><i class="fa-solid fa-pen"></i></a>${editable ? `<a data-action="itemDelete" class="danger" title="Delete"><i class="fa-solid fa-trash"></i></a>` : ""}</td></tr>`; }).join("");
    const creates = `<div class="ms-create"><i class="fa-solid fa-plus"></i> New ${(curSub ? leaves.filter(l => subNodes.some(n => n.id === l.id)) : leaves).map(l => `<a data-action="itemCreate" data-cat="${l.id}">${esc(l.name)}</a>`).join("")}</div>`;
    return `${subs}<div class="ms-card ms-table"><table><thead><tr><th class="c-name">Name</th>${cols}<th class="c-act"></th></tr></thead><tbody>${rows || `<tr><td colspan="${fields.length + 2}" class="ms-empty">Nothing here yet.</td></tr>`}</tbody></table>${editable ? creates : ""}</div>`;
  }
  #equippedHTML(cfg, editable) {
    const eq = this.actor.items.filter(i => i.system.equipped); const nodes = flattenTree(cfg.items);
    const cards = eq.map(i => { const r = rankOf(cfg, i.system.rank); const node = nodes.find(n => n.id === i.system.category); return `<div class="ms-eq" data-item="${i.id}" style="--rc:${esc(r?.color || "#fff")}"><img src="${esc(i.img)}"><div><a data-action="itemEdit"><b>${esc(i.name)}</b></a><small>${esc(node?.name || "")} · ${esc(r?.name || "")}</small></div><a data-action="itemEquip" class="eq on" title="Unequip (stays in inventory)"><i class="fa-solid fa-user-shield"></i></a></div>`; }).join("");
    return `<div class="ms-card"><div class="ms-eqhead"><i class="fa-solid fa-user-shield"></i> Worn and carried on body — ${eq.length} / ${cfg.equipment.slots || "∞"}</div><div class="ms-eqgrid">${cards || `<div class="ms-empty">Nothing equipped. Use the shield button in the inventory.</div>`}</div></div>`;
  }

  /* ───────── actions ───────── */
  static async #tab(ev, t) { this.tab = t.dataset.tab; this.render(); }
  static async #sub(ev, t) { this.sub[t.dataset.group] = t.dataset.sub; this.render(); }
  static async #stat(ev, t) {
    const key = t.closest(".ms-stat").dataset.stat; const cfg = getConfig(); const st = cfg.stats.find(x => x.key === key); if (!st) return;
    const s = this.actor.system; const v = Number(s.stats[key]) || st.min || 0; const up = t.dataset.action === "statPlus"; const p = cfg.progression; const gm = game.user.isGM;
    if (!up) { if (v <= (st.min ?? 0)) return; const upd = { [`system.stats.${key}`]: v - 1 }; if (p.paidStats && p.refundOnLower && !gm) { const res = cfg.resources.find(r => r.key === p.payWith); if (res) upd[`system.resources.${res.key}`] = (Number(s.resources[res.key]) || 0) + costOfStep(cfg, v - 1, st); } return this.actor.update(upd); }
    if (st.locked && !s.statsUnlocked?.[key]) return ui.notifications.warn(p.messages.locked);
    if ((st.max && v >= st.max) || (p.capPerStat && v >= p.capPerStat)) return ui.notifications.warn(p.messages.cap);
    if (p.capTotal && (s.statsTotal || 0) >= p.capTotal) return ui.notifications.warn(p.messages.total);
    const upd = { [`system.stats.${key}`]: v + 1 };
    if (p.paidStats && !(gm && game.settings.get(SYS, "gmFree"))) { const res = cfg.resources.find(r => r.key === p.payWith); const cost = costOfStep(cfg, v, st); const have = Number(s.resources[res?.key]) || 0; if (res && cost > have) return ui.notifications.warn(p.messages.broke.replace("{resource}", res.name)); if (res) upd[`system.resources.${res.key}`] = have - cost; }
    await this.actor.update(upd);
  }
  static async #unlockStat(ev, t) { if (!game.user.isGM) return; const key = t.closest(".ms-stat").dataset.stat; await this.actor.update({ [`system.statsUnlocked.${key}`]: true }); }
  static async #itemCreate(ev, t) { const cfg = getConfig(); const node = flattenTree(cfg.items).find(n => n.id === t.dataset.cat); const [it] = await this.actor.createEmbeddedDocuments("Item", [{ name: `New ${node?.name || "item"}`, type: "item", system: { category: t.dataset.cat, rank: cfg.ranks[0]?.key || "", rarity: cfg.rarities[0]?.key || "", equippable: fieldsOf(cfg, t.dataset.cat).includes("equippable") } }]); it?.sheet.render(true); }
  static async #itemEdit(ev, t) { this.actor.items.get(t.closest("[data-item]").dataset.item)?.sheet.render(true); }
  static async #itemDelete(ev, t) { const it = this.actor.items.get(t.closest("[data-item]").dataset.item); if (!it) return; if (await foundry.applications.api.DialogV2.confirm({ window: { title: "Delete item" }, content: `<p>Delete <b>${esc(it.name)}</b>?</p>` })) await it.delete(); }
  static async #itemEquip(ev, t) { const it = this.actor.items.get(t.closest("[data-item]").dataset.item); if (!it) return; const cfg = getConfig(); if (!it.system.equipped && cfg.equipment.slots && this.actor.items.filter(i => i.system.equipped).length >= cfg.equipment.slots) return ui.notifications.warn("All equipment slots are in use."); await it.update({ "system.equipped": !it.system.equipped }); }
  static async #itemQty(ev, t) { const it = this.actor.items.get(t.closest("[data-item]").dataset.item); if (!it) return; await it.update({ "system.quantity": Math.max(0, (Number(it.system.quantity) || 0) + Number(t.dataset.d)) }); }
  static async #equipTitle(ev, t) { const id = t.closest("[data-item]").dataset.item; await this.actor.update({ "system.equippedTitle": this.actor.system.equippedTitle === id ? "" : id }); }
}

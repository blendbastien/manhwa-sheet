/* Manhwa Sheet — data models (values only; structure comes from the world configuration) */
const F = foundry.data.fields;

export class CharacterData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      level: new F.NumberField({ integer: true, min: 0, initial: 1 }),
      rank: new F.StringField({ initial: "" }),
      awakening: new F.StringField({ initial: "" }),
      origin: new F.StringField({ initial: "" }),
      sponsor: new F.StringField({ initial: "" }),
      stats: new F.ObjectField({ initial: {} }),          /* { key: number } */
      statsUnlocked: new F.ObjectField({ initial: {} }),  /* { key: true } — GM unseals a locked stat for this character */
      resources: new F.ObjectField({ initial: {} }),      /* { key: number } */
      identity: new F.ObjectField({ initial: {} }),       /* { section: { field: value } } */
      equippedTitle: new F.StringField({ initial: "" }),  /* item id */
      equippedBag: new F.StringField({ initial: "" }),    /* item id */
      portrait: new F.StringField({ initial: "center" }), /* framing preset */
      notes: new F.HTMLField({ initial: "" })
    };
  }
  prepareDerivedData() {
    const cfg = globalThis.MANHWA?.config?.() ; if (!cfg) return;
    for (const s of cfg.stats) if (this.stats[s.key] === undefined) this.stats[s.key] = s.min ?? 1;
    for (const r of cfg.resources) if (this.resources[r.key] === undefined) this.resources[r.key] = r.start ?? 0;
    this.statsTotal = cfg.stats.reduce((n, s) => n + (Number(this.stats[s.key]) || 0), 0);
    if (!this.rank && cfg.ranks[0]) this.rank = cfg.ranks[0].key;
    if (!this.awakening && cfg.awakening[0]) this.awakening = cfg.awakening[0].key;
  }
}
export class NpcData extends CharacterData {}

export class ItemData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      category: new F.StringField({ initial: "" }),       /* leaf id of the item tree */
      rank: new F.StringField({ initial: "" }),
      rarity: new F.StringField({ initial: "" }),
      quantity: new F.NumberField({ integer: true, min: 0, initial: 1 }),
      value: new F.NumberField({ min: 0, initial: 0 }),
      level: new F.NumberField({ integer: true, min: 0, initial: 1 }),
      element: new F.StringField({ initial: "" }),
      cost: new F.StringField({ initial: "" }),
      range: new F.StringField({ initial: "" }),
      execution: new F.StringField({ initial: "" }),
      origin: new F.StringField({ initial: "" }),
      manufacturer: new F.StringField({ initial: "" }),
      capacity: new F.NumberField({ integer: true, min: 0, initial: 0 }),
      slots: new F.NumberField({ integer: true, min: 0, initial: 0 }),
      equippable: new F.BooleanField({ initial: false }),
      equipped: new F.BooleanField({ initial: false }),   /* worn / carried on body — never removed from inventory */
      fx: new F.StringField({ initial: "" }),             /* cosmetic animated name */
      description: new F.HTMLField({ initial: "" }),
      lore: new F.HTMLField({ initial: "" }),
      extra: new F.ObjectField({ initial: {} })            /* GM-defined free fields */
    };
  }
}

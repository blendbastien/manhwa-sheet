/* Manhwa Sheet — item sheet (fields come from the item's category in the tree) */
import { esc, getConfig, flattenTree, fieldsOf, ITEM_FIELDS } from "./config.js";
const { ItemSheetV2 } = foundry.applications.sheets;
export const FX = ["", "flame", "frost", "storm", "void", "holy", "blood", "nature", "gold", "shadow", "glitch", "prism"];

export class ManhwaItemSheet extends ItemSheetV2 {
  static DEFAULT_OPTIONS = { classes: ["ms-sheet", "ms-item"], position: { width: 620, height: 640 }, window: { resizable: true, icon: "fa-solid fa-cube" }, form: { submitOnChange: true, closeOnSubmit: false } };
  get title() { return this.item.name; }
  async _renderHTML() {
    const i = this.item, s = i.system, cfg = getConfig(); const nodes = flattenTree(cfg.items); const leaves = nodes.filter(n => !n.children?.length);
    const node = nodes.find(n => n.id === s.category); const fields = fieldsOf(cfg, s.category);
    const catOpts = leaves.map(l => { const path = []; let n = l; while (n) { path.unshift(n.name); n = n.parent; } return `<option value="${l.id}"${l.id === s.category ? " selected" : ""}>${esc(path.join(" › "))}</option>`; }).join("");
    const listSel = (name, list, cur) => `<select name="${name}"><option value="">—</option>${(cfg[list] || []).map(o => `<option value="${esc(o.key)}"${o.key === cur ? " selected" : ""}>${esc(o.name)}</option>`).join("")}</select>`;
    const field = f => { const d = ITEM_FIELDS[f]; if (!d) return ""; const n = `system.${f}`; const v = s[f];
      if (d.kind === "rank") return `<label class="ms-f"><span>Rank</span><select name="${n}">${cfg.ranks.map(r => `<option value="${esc(r.key)}"${r.key === v ? " selected" : ""}>${esc(r.name)}</option>`).join("")}</select></label>`;
      if (d.kind === "list") return `<label class="ms-f"><span>${esc(d.label)}</span>${listSel(n, d.list, v)}</label>`;
      if (d.kind === "origin") return `<label class="ms-f"><span>Origin</span>${cfg.origins.length ? listSel(n, "origins", v) : `<input type="text" name="${n}" value="${esc(v)}">`}</label>`;
      if (d.kind === "number") return `<label class="ms-f"><span>${esc(d.label)}</span><input type="number" name="${n}" value="${esc(v)}"></label>`;
      if (d.kind === "boolean") return `<label class="ms-f chk"><input type="checkbox" name="${n}"${v ? " checked" : ""}><span>${esc(d.label)}</span></label>`;
      if (d.kind === "rich") return `<label class="ms-f wide"><span>${esc(d.label)}</span><textarea name="${n}" rows="4">${esc(v)}</textarea></label>`;
      return `<label class="ms-f"><span>${esc(d.label)}</span><input type="text" name="${n}" value="${esc(v)}"></label>`; };
    const root = (() => { let n = node; while (n?.parent) n = n.parent; return n; })();
    return `<div class="ms-wrap ms-itemwrap" style="--rc:${esc(root?.color || "#38a8ff")}">
      <header class="ms-head small"><img src="${esc(i.img)}" data-action="editImage" data-edit="img" title="Click to change the image"><div class="ms-idblock"><input class="ms-name" type="text" name="name" value="${esc(i.name)}">
        <div class="ms-row"><label class="ms-f grow"><span>Category</span><select name="system.category">${catOpts}</select></label><label class="ms-f"><span>Name effect</span><select name="system.fx">${FX.map(f => `<option value="${f}"${f === s.fx ? " selected" : ""}>${f || "none"}</option>`).join("")}</select></label></div></div></header>
      <section class="ms-body"><div class="ms-card"><div class="ms-grid2">${fields.filter(f => f !== "lore").map(field).join("")}</div></div>
      <div class="ms-card"><label class="ms-f wide"><span>Description</span><textarea name="system.description" rows="6">${esc(s.description)}</textarea></label>${fields.includes("lore") ? field("lore") : ""}</div></section></div>`;
  }
  _replaceHTML(result, content) { content.innerHTML = result; }
}

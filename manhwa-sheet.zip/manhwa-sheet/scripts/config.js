/* Manhwa Sheet — configuration (world setting), defaults, helpers */
export const SYS = "manhwa-sheet";
export const esc = s => foundry.utils.escapeHTML(String(s ?? ""));
export const uid = () => foundry.utils.randomID(8);

export const THEMES = { "solo-neon": "Solo Neon (electric blue)", "orv-violet": "Violet Neon (ORV)", crimson: "Crimson (murim)", gold: "Gold (senate)", mono: "Mono (black minimal)" };

/* field catalog for item categories */
export const ITEM_FIELDS = {
  rank: { label: "Rank", kind: "rank" }, rarity: { label: "Rarity", kind: "list", list: "rarities" }, quantity: { label: "Quantity", kind: "number" }, value: { label: "Value", kind: "number" },
  level: { label: "Level", kind: "number" }, element: { label: "Element", kind: "list", list: "elements" }, cost: { label: "Cost", kind: "list", list: "costs" }, range: { label: "Range", kind: "list", list: "ranges" },
  execution: { label: "Execution", kind: "list", list: "executions" }, origin: { label: "Origin", kind: "origin" }, manufacturer: { label: "Manufacturer", kind: "text" }, capacity: { label: "Capacity", kind: "number" },
  slots: { label: "Equipment slots granted", kind: "number" }, equippable: { label: "Equippable", kind: "boolean" }, lore: { label: "Lore", kind: "rich" }
};

export const DEFAULT_CONFIG = {
  v: 1,
  stats: [
    { key: "str", name: "Strength", abbr: "STR", icon: "fa-hand-fist", color: "#ff4d5e", min: 1, max: 99, costMult: 1, locked: false },
    { key: "agi", name: "Agility", abbr: "AGI", icon: "fa-person-running", color: "#38e0ff", min: 1, max: 99, costMult: 1, locked: false },
    { key: "vit", name: "Vitality", abbr: "VIT", icon: "fa-heart-pulse", color: "#5aff9a", min: 1, max: 99, costMult: 1, locked: false },
    { key: "int", name: "Intelligence", abbr: "INT", icon: "fa-brain", color: "#7ad7ff", min: 1, max: 99, costMult: 1, locked: false },
    { key: "per", name: "Perception", abbr: "PER", icon: "fa-eye", color: "#ffd070", min: 1, max: 99, costMult: 1, locked: false },
    { key: "wil", name: "Will", abbr: "WIL", icon: "fa-fire", color: "#ff8af0", min: 1, max: 99, costMult: 1, locked: false },
    { key: "mana", name: "Mana", abbr: "MANA", icon: "fa-wand-sparkles", color: "#b980ff", min: 1, max: 99, costMult: 1.5, locked: false },
    { key: "luck", name: "Luck", abbr: "LUCK", icon: "fa-clover", color: "#c9f06a", min: 1, max: 99, costMult: 1, locked: false }
  ],
  statColorMode: "card",                          /* card | number | watermark */
  resources: [{ key: "coins", name: "Coins", icon: "fa-coins", color: "#ffd070", start: 0, min: 0, inHeader: true, paysStats: true }],
  ranks: [
    { key: "E", name: "E", color: "#9aaac8" }, { key: "D", name: "D", color: "#5aa6f0" }, { key: "C", name: "C", color: "#20d8f8" }, { key: "B", name: "B", color: "#b46bff" },
    { key: "A", name: "A", color: "#34d46e" }, { key: "S", name: "S", color: "#f5c842" }, { key: "S+", name: "S+", color: "#ff7a2a" }
  ],
  rankColor: { targets: ["badge", "name"], intensity: 1, rarityOwnColor: false },  /* targets: badge | name | row | glow | hex */
  awakening: [{ key: "unawakened", name: "Unawakened", color: "#8ea0c8" }, { key: "awakened", name: "Awakened", color: "#38a8ff" }, { key: "transcended", name: "Transcended", color: "#ffd070" }],
  origins: [],
  rarities: [{ key: "common", name: "Common", color: "#9aaac8" }, { key: "uncommon", name: "Uncommon", color: "#34d46e" }, { key: "rare", name: "Rare", color: "#5aa6f0" }, { key: "epic", name: "Epic", color: "#b46bff" }, { key: "legendary", name: "Legendary", color: "#f5c842" }, { key: "mythic", name: "Mythic", color: "#ff7a2a" }],
  elements: [{ key: "none", name: "None", color: "#8ea0c8" }, { key: "fire", name: "Fire", color: "#ff6a3d" }, { key: "water", name: "Water", color: "#38a8ff" }, { key: "earth", name: "Earth", color: "#c9a06a" }, { key: "wind", name: "Wind", color: "#8fe3c8" }, { key: "lightning", name: "Lightning", color: "#ffe066" }, { key: "light", name: "Light", color: "#fff1b8" }, { key: "dark", name: "Dark", color: "#9b6bff" }],
  costs: [{ key: "none", name: "None" }, { key: "low", name: "Low" }, { key: "medium", name: "Medium" }, { key: "high", name: "High" }, { key: "extreme", name: "Extreme" }],
  ranges: [{ key: "self", name: "Self" }, { key: "melee", name: "Melee" }, { key: "short", name: "Short" }, { key: "medium", name: "Medium" }, { key: "long", name: "Long" }, { key: "area", name: "Area" }],
  executions: [{ key: "instant", name: "Instant" }, { key: "action", name: "Action" }, { key: "channeled", name: "Channeled" }, { key: "reaction", name: "Reaction" }, { key: "passive", name: "Passive" }],
  /* item tree : id, name, icon, color, fields (inherited by children unless they define their own), children */
  items: [
    { id: "equipment", name: "Equipment", icon: "fa-shield-halved", color: "#38a8ff", fields: ["rank", "rarity", "quantity", "value", "equippable", "lore"], children: [
      { id: "weapons", name: "Weapons", icon: "fa-khanda", children: [] }, { id: "armor", name: "Armor", icon: "fa-shirt", children: [] }, { id: "accessories", name: "Accessories", icon: "fa-ring", children: [] },
      { id: "consumables", name: "Consumables", icon: "fa-flask", fields: ["rank", "rarity", "quantity", "value", "lore"], children: [] }, { id: "ammo", name: "Ammo", icon: "fa-bullseye", fields: ["rank", "rarity", "quantity", "value", "lore"], children: [] }, { id: "loot", name: "Loot", icon: "fa-gem", fields: ["rank", "rarity", "quantity", "value", "lore"], children: [] } ] },
    { id: "skills", name: "Skills", icon: "fa-bolt", color: "#b980ff", fields: ["level", "rank", "rarity", "element", "cost", "range", "execution", "value", "lore"], children: [
      { id: "active", name: "Active", icon: "fa-burst", children: [] }, { id: "spells", name: "Spells", icon: "fa-wand-sparkles", children: [] }, { id: "passive", name: "Passive", icon: "fa-shield", children: [] }, { id: "other", name: "Other", icon: "fa-asterisk", children: [] } ] },
    { id: "titles", name: "Titles", icon: "fa-crown", color: "#ffd070", fields: ["rank", "rarity", "equippable", "lore"], children: [] },
    { id: "bags", name: "Bags", icon: "fa-sack-xmark", color: "#c9a06a", fields: ["rank", "rarity", "capacity", "slots", "value", "equippable", "lore"], children: [] },
    { id: "companions", name: "Companions", icon: "fa-paw", color: "#5aff9a", fields: ["level", "rank", "rarity", "element", "value", "lore"], children: [] },
    { id: "vehicles", name: "Vehicles", icon: "fa-car", color: "#7ad7ff", fields: ["rank", "rarity", "manufacturer", "origin", "value", "lore"], children: [] },
    { id: "properties", name: "Properties", icon: "fa-house", color: "#ff8af0", fields: ["rank", "rarity", "origin", "value", "lore"], children: [] }
  ],
  identity: [
    { key: "personal", name: "Personal", fields: [{ key: "age", label: "Age", kind: "short" }, { key: "hand", label: "Dominant hand", kind: "select", options: ["Right", "Left", "Ambidextrous"] }, { key: "race", label: "Race / Species", kind: "short" }, { key: "height", label: "Height", kind: "short" }, { key: "faction", label: "Faction / Guild", kind: "short" }, { key: "affiliation", label: "Secondary affiliation", kind: "short" }, { key: "personal", label: "Personal notes", kind: "rich" }, { key: "background", label: "Background", kind: "rich" }] },
    { key: "physique", name: "Physique", fields: [{ key: "build", label: "Build", kind: "short" }, { key: "skin", label: "Skin", kind: "short" }, { key: "hair", label: "Hair", kind: "short" }, { key: "eyes", label: "Eyes", kind: "short" }, { key: "vision", label: "Vision (glasses, lenses…)", kind: "short" }, { key: "health", label: "Health (past, present, future)", kind: "short" }, { key: "marks", label: "Distinctive marks", kind: "rich" }] },
    { key: "appearance", name: "Appearance", fields: [{ key: "clothes", label: "Clothing (style, colors, brands…)", kind: "rich" }, { key: "jewelry", label: "Accessories (jewelry…)", kind: "short" }, { key: "hairstyle", label: "Hairstyle", kind: "short" }, { key: "tattoos", label: "Tattoos / piercings", kind: "short" }, { key: "makeup", label: "Makeup", kind: "short" }] },
    { key: "family", name: "Family", fields: [{ key: "parents", label: "Parents (names, ages)", kind: "short" }, { key: "parentsStatus", label: "Parents together, divorced, remarried?", kind: "short" }, { key: "parentsJobs", label: "Parents' occupations", kind: "short" }, { key: "siblings", label: "Siblings", kind: "rich" }, { key: "relParents", label: "Relationship with parents", kind: "short" }, { key: "relSiblings", label: "Relationship with siblings", kind: "short" }, { key: "others", label: "Other important relatives", kind: "rich" }, { key: "pets", label: "Pets", kind: "short" }] },
    { key: "daily", name: "Daily life", fields: [{ key: "schedule", label: "Wakes up / goes to bed at", kind: "short" }, { key: "transport", label: "Gets around by", kind: "short" }, { key: "housing", label: "Housing", kind: "short" }, { key: "habits", label: "Daily habits", kind: "rich" }, { key: "sayings", label: "Favorite expressions", kind: "short" }, { key: "food", label: "Favorite food & drinks", kind: "short" }, { key: "diet", label: "Eating habits", kind: "rich" }, { key: "likes", label: "Likes (daily)", kind: "short" }, { key: "dislikes", label: "Dislikes (daily)", kind: "short" }, { key: "sports", label: "Sports", kind: "short" }, { key: "tech", label: "Tech proficiency", kind: "short" }, { key: "languages", label: "Languages", kind: "short" }, { key: "public", label: "Behavior in public", kind: "short" }] },
    { key: "relations", name: "Relationships", fields: [{ key: "bestFriend", label: "Best friend", kind: "short" }, { key: "friends", label: "Other friends", kind: "rich" }, { key: "relFriends", label: "Relationship with friends", kind: "rich" }] },
    { key: "personality", name: "Personality", fields: [{ key: "qualities", label: "Qualities", kind: "rich" }, { key: "flaws", label: "Flaws — impact on life and relationships", kind: "rich" }, { key: "religion", label: "Religion", kind: "short" }, { key: "politics", label: "Political views", kind: "short" }, { key: "desire", label: "Deepest desire", kind: "short" }, { key: "successes", label: "Successes", kind: "short" }, { key: "failures", label: "Failures", kind: "short" }, { key: "hopes", label: "Hopes", kind: "short" }, { key: "fears", label: "Fears", kind: "short" }, { key: "details", label: "Worldview, achievements, passions…", kind: "rich" }, { key: "likesPlus", label: "Likes (+)", kind: "short" }, { key: "likesMinus", label: "Dislikes (−)", kind: "short" }] }
  ],
  progression: {
    paidStats: false, payWith: "coins", refundOnLower: false,
    costMode: "tiers",                                   /* tiers | multiplier | manual */
    tiers: [{ from: 1, to: 10, cost: 100 }, { from: 11, to: 30, cost: 250 }, { from: 31, to: 60, cost: 600 }, { from: 61, to: 99, cost: 1500 }],
    multiplier: { base: 100, perPoint: 25 },              /* cost of value v → v+1 = base + perPoint × (v − 1) */
    manual: [],                                          /* manual[v] = cost of v → v+1 */
    capPerStat: 0, capTotal: 0,                          /* 0 = none */
    tierEvery: 10, tierNames: ["Novice", "Apprentice", "Adept", "Expert", "Master", "Grandmaster", "Legend", "Myth", "Transcendent"],
    messages: { locked: "[ This stat is sealed. ]", cap: "[ Stat limit reached. ]", total: "[ Total stat limit reached. ]", broke: "[ Insufficient {resource}. ]" }
  },
  equipment: { enabled: false, slots: 4 }                /* "on body" equipment area, off by default */
};

export function getConfig() { const c = foundry.utils.mergeObject(foundry.utils.deepClone(DEFAULT_CONFIG), game.settings.get(SYS, "config") || {}, { inplace: false, insertKeys: true, insertValues: true, overwrite: true, recursive: true }); return c; }
export async function setConfig(c) { if (!game.user.isGM) return; await game.settings.set(SYS, "config", c); }
export async function updateConfig(fn) { const c = getConfig(); const r = await fn(c); if (r !== false) await setConfig(c); return c; }

/* theme */
export function applyTheme() {
  const t = game.settings.get(SYS, "theme") || "solo-neon"; const a = game.settings.get(SYS, "anim") || "low";
  document.body.dataset.msTheme = t; document.documentElement.classList.toggle("ms-anim-low", a === "low"); document.documentElement.classList.toggle("ms-anim-off", a === "off");
}

/* ── stat costs ── */
export function costOfStep(cfg, v, stat) {
  const p = cfg.progression; let c = 0;
  if (p.costMode === "multiplier") c = p.multiplier.base + p.multiplier.perPoint * (v - 1);
  else if (p.costMode === "manual") c = Number(p.manual[v]) || 0;
  else { const t = p.tiers.find(x => v >= x.from && v <= x.to); c = t ? t.cost : (p.tiers[p.tiers.length - 1]?.cost || 0); }
  return Math.round(c * (stat?.costMult || 1));
}
export function costBetween(cfg, from, to, stat) { let s = 0; for (let v = from; v < to; v++) s += costOfStep(cfg, v, stat); return s; }
export function rankOf(cfg, key) { return cfg.ranks.find(r => r.key === key) || cfg.ranks[0]; }
export function listOf(cfg, name) { return cfg[name] || []; }

/* item tree helpers */
export function flattenTree(nodes, parent = null, depth = 0, out = []) { for (const n of nodes || []) { out.push({ ...n, parent, depth, path: parent ? `${parent.path}/${n.id}` : n.id }); flattenTree(n.children, out[out.length - 1], depth + 1, out); } return out; }
export function findNode(cfg, id) { return flattenTree(cfg.items).find(n => n.id === id) || null; }
export function fieldsOf(cfg, id) { let n = findNode(cfg, id); while (n) { if (n.fields && n.fields.length) return n.fields; n = n.parent; } return ["rank", "rarity", "quantity", "value", "lore"]; }
export function rootOf(cfg, id) { let n = findNode(cfg, id); while (n && n.parent) n = n.parent; return n; }

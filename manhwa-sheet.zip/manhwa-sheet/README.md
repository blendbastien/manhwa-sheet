# Manhwa Sheet (v0.1 — skeleton)

Standalone Foundry VTT v13 system for manhwa-style play (hunters, regressors, murim, system apocalypses).

**v0.1 scope (test build):** configurable stats, currencies, ranks & color behavior, awakening states, origins, lists (rarities, elements, costs, ranges, executions), item category tree with inherited field sets, identity sections, progression (paid stats off by default; cost by tiers / formula / one by one; caps; tiers), themes (GM-imposed world setting), character sheet (header, stats, identity, item tabs built from the tree, optional Equipped tab), item sheet.

Everything lives in **Configure Settings → Manhwa Sheet**: *Sheet configuration*, *Progression & costs*, *Theme*. Export/import the configuration as JSON.

Fonts bundled under OFL (Orbitron, Rajdhani, Share Tech Mono, Cinzel). Icons: Font Awesome Free (shipped with Foundry).
